#include "ch.h"
#include "hal.h"
static SerialConfig uartCfg =
{
9600, // bit rate
};
int main(void){
halInit(); // initialize Hardware Abstraction Layer
chSysInit(); // initialize ChibiOS kernel
/* sdInit(); should be used as we see in the SerialDriver state machine
, but it is already implicitely called in halInit();*/
palSetPadMode(GPIOB, 10, PAL_MODE_ALTERNATE(7)); // used function : USART3_TX
palSetPadMode(GPIOB, 11, PAL_MODE_ALTERNATE(7)); // used function : USART3_RX
sdStart(&SD3, &uartCfg); // starts the serial driver with uartCfg as a config
char data[] = "Hello World ! \n \r"; /* we create the string "Hello World!", \n means go to the next line
\r sets it to the left of the screen */
while(1){
sdWrite(&SD3, (uint8_t *) data, strlen(data)); // Writes "Hello World in the UART output
chThdSleepMilliseconds(500);
}
} 
