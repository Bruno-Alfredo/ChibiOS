#ifndef TRANSITIONS_H
#define TRANSITIONS_H

#include "event.h"
#include "sm.h"


//cb_status init_cb(event_t ev);
cb_status Aguardando_ACK(event_t ev);
cb_status Enviando_Dados(event_t ev);
cb_status Recebendo_Dados(event_t ev);


#define Init_Aguardando_ACK_tran() do {         \
                push_state(Aguardando_ACK);     \
                dispatch(ENTRY_EVENT);          \
        } while (0)

#define Aguardando_ACK_Enviando_Dados_tran() do {   \
                replace_state(Enviando_Dados);       \
                dispatch(ENTRY_EVENT);          \
        } while (0)
        
#define Aguardando_ACK_Recebendo_Dados_tran() do {                      \
                replace_state(Recebendo_Dados);       \
                dispatch(ENTRY_EVENT);          \
        } while (0)
        
#define Enviando_dados_Recebendo_dados_tran() do {              \
                replace_state(Recebendo_Dados);       \
                dispatch(ENTRY_EVENT);          \
        } while (0)        

#define Recebendo_dados_Enviando_dados_tran() do {        \
                replace_state(Enviando_Dados);       \
                dispatch(ENTRY_EVENT);          \
        } while (0)


#endif /* TRANSITIONS_H */
