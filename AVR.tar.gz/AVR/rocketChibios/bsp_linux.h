#ifndef BSP_LINUX_H
#define BSP_LINUX_H


void bsp_init(void);
void enter_critical_region(void);
void leave_critical_region(void);

#endif /* BSP_LINUX_H */
