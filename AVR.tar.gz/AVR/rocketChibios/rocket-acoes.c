#include <stdio.h>


#define SOT_TIMEOUT 3
#define DOWNLINK_DURATION 6
#define UPLINK_DURATION 4
#define NO_RESPONSE_TIMEOUT 3

int message_retrieve(message_manager_t* mgr, uint8_t* buffer, int nbr_bytes) {
    char msg[] = "MSG_RETRIEVED";
    int msg_len = sizeof(msg) > nbr_bytes ? nbr_bytes : sizeof(msg);
    strncpy(buffer, msg, msg_len);

    return msg_len;
}


void send_sot() {
    const uint8_t sot[] = "SOT";
    sdWrite(&SD1, (const uint8_t*) sot, strlen(sot));

}


void send_eot() {
    const uint8_t eot[] = "EOT";
    sdWrite(&SD1, (const uint8_t*) eot, strlen(eot));   // como verificar erro se sdWrite falhar?

}

void send_first_data() {
    int actual_nbr_bytes;
    uint8_t buffer[50];
    int nbr_bytes = sizeof(buffer);
    if ((actual_nbr_bytes = message_retrieve(&g_msg_mgr, buffer, nbr_bytes)) == 0) {
       // printf("In send_first_data(), there was no message to be retrieved from the queue.\n");
        return;
    }

    nbr_bytes = actual_nbr_bytes;
    sdWrite(&SD1, (const uint8_t*) buffer, nbr_bytes);

}

void send_data() {
    int actual_nbr_bytes;
    uint8_t buffer[50];
    int nbr_bytes = sizeof(buffer);

    if ((actual_nbr_bytes = message_retrieve(&g_msg_mgr, buffer, nbr_bytes)) == 0) {
       // printf("In send_first_data(), there was no message to be retrieved from the queue\n");
        return;
    }

     nbr_bytes = actual_nbr_bytes;
     sdWrite(&SD1, (const uint8_t*) buffer, nbr_bytes);   //SD1? o que é
}






