#include <stdio.h>
#include <pthread.h>
#include <stdint.h>
#include "event.h"
#include "sm.h"
#include "transitions.h"

enum {
        EVENT_ACK =USER_EVENT,
        EVENT_SOT,
        EVENT_TOUT_SOT,
        EVENT_TOUT_SESSION_TX,
        EVENT_TOUT_NO_RX,
        EVENT_TOUT_SESSION_RX,
        EVENT_EOT,
        EVENT_DADOS,
        EVENT_DATA_SENT,
        EVENT_NO_DATA,
        EVENT_INVALID,
        EVENT_MAX,
        EVENT_DESCONHECIDO
};

uint8_t foo;

cb_status init_cb (event_t ev)
{
         foo = 0;
         printf("enviando SOT");
       //  send_sot();
         Init_Aguardando_ACK_tran();
         return EVENT_HANDLED;
}

cb_status Aguardando_ACK(event_t ev)
{
          switch(ev) {
          case ENTRY_EVENT:
               printf("Aguardando_ACK-ENTRY; ");
               return EVENT_HANDLED;

          case EVENT_ACK:
               printf("Recebido EVENT_ACK; ");
               //if (has_message(&g_msg_mgr))
               //{
                   printf("Eviando primeiros dados apos ACK; ");
                  // send_first_data();
                   Aguardando_ACK_Enviando_Dados_tran(); 
                   return EVENT_HANDLED;
               //}
               //else {
                 //   printf("Sem dados, enviando EOT; ");
                   // send_eot();
                   // Aguardando_ACK_Recebendo_Dados_tran();
                    //return EVENT_HANDLED;
               }


}

cb_status Enviando_Dados(event_t ev)
{
          switch(ev) {
          case ENTRY_EVENT:
               printf("Enviando_Dados-ENTRY; ");
               return EVENT_HANDLED;

          case EVENT_DATA_SENT:
               printf("Dados enviados; ");
          //     if ( /*timeout*/ || !has_message(&g_msg_mgr))
              // {
                    //timer_reset();
                    // g_session_over =0;
                 //   send_eot();
                    Enviando_dados_Recebendo_dados_tran();
                    return EVENT_HANDLED;
            //   }
            //   else{
                   // send_data()
           //         return EVENT_HANDLED;
               }

}

cb_status Recebendo_Dados(event_t ev)
{
          switch(ev) {
          case ENTRY_EVENT:
               printf("Recebendo_Dados-ENTRY; ");
               return EVENT_HANDLED;
        /*case EVENT_TOUT_NO_RX  
               timer_reset();
               send_sot();
               Recebendo_dados_Aguardando_ACK_tran();
               return EVENT_HANDLED;
        */
          case EVENT_EOT:
              // if(has_message(&g_msg_mgr))
               //{
                  //timer_reset();
                 // send_first_data();
                  Recebendo_dados_Enviando_dados_tran();
                  return EVENT_HANDLED;
               // }
               // else{
                //    send_eot();
               //     return EVENT_HANDLED;
              //  }
          case EVENT_DADOS:
               printf("leitura dos dados recebidos; ");
              // processa_dados();
               return EVENT_HANDLED;
          
          case EVENT_TOUT_SESSION_RX:
              // tout_rx_session();
               return EVENT_HANDLED;

}
         }

pthread_mutex_t handling_mutex;
pthread_cond_t handling_cv;


void *event_thread(void *vargp)
{
        event_t ev;

        while (1) {
                ev = wait_for_events();
                if (ev == EMPTY_EVENT)
                        break;
                printf("\n");
                dispatch_event(ev);
                pthread_mutex_lock(&handling_mutex);
                pthread_cond_signal(&handling_cv);
                pthread_mutex_unlock(&handling_mutex);
        }

        return NULL;
}


int main(int argc, char* argv[])
{
        char *ptr;
        pthread_t tid;
                     
        if (argc < 2) {
                fprintf(stderr, "Usage: %s inputs\n", argv[0]);
                return -1;
        }

        pthread_mutex_init(&handling_mutex, 0);
        pthread_cond_init(&handling_cv, 0);
        pthread_create(&tid, NULL, event_thread, NULL);
         
        init_machine(init_cb);
        ptr = argv[1];
        while(*ptr) {
                switch (*ptr++) {
                case 'A':
                case 'a':
                        set_event(EVENT_ACK);
                        break;
                case 'B':
                case 'b':
                        set_event(EVENT_SOT);
                        break;
                case 'C':
                case 'c':
                        set_event(EVENT_TOUT_SOT);
                        break;
                case 'D':
                case 'd':
                        set_event(EVENT_TOUT_SESSION_TX);
                        break;
                case 'E':
                case 'e':
                        set_event(EVENT_TOUT_NO_RX);
                        break;
                case 'F':
                case 'f':
                        set_event(EVENT_TOUT_SESSION_RX);
                        break;
                case 'G':
                case 'g':
                        set_event(EVENT_EOT);
                        break;
                case 'H':
                case 'h':
                        set_event(EVENT_DADOS);
                        break;
                case 'I':
                case 'i':
                        set_event(EVENT_DATA_SENT);
                        break;
                case 'J':
                case 'j':
                        set_event(EVENT_NO_DATA);
                        break;
                case 'K':
                case 'k':
                        set_event(EVENT_INVALID);
                        break;
                case 'L':
                case 'l':
                        set_event(EVENT_MAX);
                        break;
                default:
                        set_event(EVENT_MAX+1);
                        /* continue; */
                }
                pthread_mutex_lock(&handling_mutex);
                pthread_cond_wait(&handling_cv, &handling_mutex);
                pthread_mutex_unlock(&handling_mutex);
        }
        printf("\n");

        set_event(EMPTY_EVENT);
        pthread_join(tid, NULL);

        return 0;
}       





