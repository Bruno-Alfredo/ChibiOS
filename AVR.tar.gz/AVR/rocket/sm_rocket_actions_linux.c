#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "sm_rocket.h"
#include "event.h"


#define SOT_TIMEOUT 3
#define DOWNLINK_DURATION 6
#define UPLINK_DURATION 4
#define NO_RESPONSE_TIMEOUT 3

void send_sot() {
    const uint8_t sot[] = "SOT";
    if (radio_send(&g_radio, sot, sizeof(sot)))
        perror("On sending SOT in send_sot()");

    if (timer_set(&g_timer_mgr, SOT_TIMER_ID, SOT_TIMEOUT, EV_TOUT_SOT))
        perror("On setting timer SOT_TIMER_ID in send_sot()");
}

void send_first_data() {
    int actual_nbr_bytes;
    uint8_t buffer[50];
    int nbr_bytes = sizeof(buffer);

    printf("Enviando o primeiro dado da sessão. Continua no estado 'ENVIANDO DADOS'\n");
    if ((actual_nbr_bytes = message_retrieve(&g_msg_mgr, buffer, nbr_bytes)) == 0) {
        printf("In send_first_data(), there was no message to be retrieved from the queue.\n");
        return;
    }
    nbr_bytes = actual_nbr_bytes;
    if ((actual_nbr_bytes = radio_send(&g_radio, buffer, nbr_bytes)) != nbr_bytes) {
        printf("In send_first_data(), radio didn't send all bytes.\n");
    }
    if (timer_set(&g_timer_mgr, DOWNLINK_TIMER_ID, DOWNLINK_DURATION, EV_TOUT_SESSION_TX))
        printf("Error on setting timer DOWNLINK_TIMER_ID in send_first_data().\n");
}

void send_eot() {
    const uint8_t eot[] = "EOT";
    if (radio_send(&g_radio, eot, sizeof(eot)))
        printf("Error on sending EOT in send_eot().\n");

    if (timer_set(&g_timer_mgr, UPLINK_TIMER_ID, UPLINK_DURATION, EV_TOUT_SESSION_RX))
        printf("Error on setting timer UPLINK_TIMER_ID in send_eot().\n");

    if (timer_set(&g_timer_mgr, UPLINK_RX_TIMER_ID, NO_RESPONSE_TIMEOUT, EV_TOUT_NO_RX))
        printf("Error on setting timer UPLINK_RX_TIMER_ID in send_eot().\n");
}

void send_data() {
    int actual_nbr_bytes;
    uint8_t buffer[50];
    int nbr_bytes = sizeof(buffer);

    printf("Enviando dados. Continua no estado 'ENVIANDO DADOS'\n");
    if ((actual_nbr_bytes = message_retrieve(&g_msg_mgr, buffer, nbr_bytes)) == 0) {
        printf("In send_first_data(), there was no message to be retrieved from the queue\n");
        return;
    }
    nbr_bytes = actual_nbr_bytes;
    if ((actual_nbr_bytes = radio_send(&g_radio, buffer, nbr_bytes)) != nbr_bytes) {
        printf("In send_first_data(), radio didn't send all bytes\n");
    }
}

void processa_dados() {
    printf("Continua no estado 'RECEBENDO DADOS'\n");
}

void tout_rx_sessao() {
    printf("In tout_rx_sessao(), session is longer than expected.\n");
    printf("Continua no estado 'RECEBENDO DADOS'\n");
}
