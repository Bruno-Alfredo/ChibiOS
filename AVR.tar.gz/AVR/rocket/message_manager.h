#ifndef MESSAGE_MANAGER_H
#define MESSAGE_MANAGER_H

typedef struct message_manager_struct message_manager_t;

int message_init_manager(message_manager_t*);
int message_deinit_manager(message_manager_t*);
int has_message(message_manager_t*);
int message_retrieve(message_manager_t*, uint8_t*, int);
int message_delivery(message_manager_t*, uint8_t*, int);

#ifdef __linux__
#include "message_manager_linux.h"
#elif defined __AVR__
#include "message_manager_chibios.h"
#endif

#endif /* MESSAGE_MANAGER_H */
