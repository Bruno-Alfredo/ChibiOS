#include <stdio.h>
#include <signal.h>
#include <time.h>

#include "timer_manager.h"


struct itimerspec specx;
   // spec.it_interval.tv_sec = 0;
   // spec.it_interval.tv_nsec = 0;
   // spec.it_value.tv_sec = 0;
   // spec.it_value.tv_nsec = 0;

void timer_cb(union sigval value) {
    timer_cb_arg_t* arg = value.sival_ptr;
    printf("Timer went off: %p\n", arg);
    if (arg && arg->_cb) {
        printf("cb = %p, event = %u\n", arg->_cb, arg->_event);
        arg->_cb(arg->_event);
    }
}

int timer_init_manager(timer_manager_t *mgr, uint8_t nbr_timers, timer_cb_t cb) {
    int rc = 0;
    struct sigevent sigev;

    sigev.sigev_notify = SIGEV_THREAD;
    sigev.sigev_value.sival_ptr = 0;
    sigev.sigev_notify_function = timer_cb;
    sigev.sigev_notify_attributes = 0;

    for (int i=0; i<nbr_timers; i++) {
        mgr->_args[i]._cb = cb;
        sigev.sigev_value.sival_ptr = &mgr->_args[i];
        if(timer_create(CLOCK_REALTIME, &sigev, &mgr->_timers[i])) {
            perror("On timer creation: ");
            rc = 1;
        }
    }

    mgr->_nbr_timers = nbr_timers;

    return rc;
}

int timer_deinit_manager(timer_manager_t *mgr) {
    int rc = 0;

    for(int i=0; i<mgr->_nbr_timers; i++)
        if(timer_delete(mgr->_timers[i]))  {
            perror("On destroying timer: ");
            rc= 1;
        }

    return rc;
}

int timer_set(timer_manager_t *mgr, uint8_t timer_id, uint16_t sec, uint8_t event) {
    int rc = 0;

    mgr->_args[timer_id]._event = event;

    struct itimerspec spec;
    spec.it_interval.tv_sec = 0;
    spec.it_interval.tv_nsec = 0;
    spec.it_value.tv_sec = sec;
    spec.it_value.tv_nsec = 0;

    if (timer_settime(mgr->_timers[timer_id], 0, &spec, 0)) {
        perror("On setting timer: ");
        rc = 1;
    }

    

    return rc;
}

int timer_reset(timer_manager_t * mgr, uint8_t timer_id) {
    return timer_set(mgr, timer_id, 0, 0);
}
