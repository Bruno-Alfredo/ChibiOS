#include <stdio.h>

#include "sm_rocket.h"
#include "event.h"


const char* EV_NAMES[] = {"EV_ACK", "EV_SOT", "EV_TOUT_SOT", "EV_TOUT_SESSION_TX",
    "EV_TOUT_NO_RX", "EV_TOUT_SESSION_RX", "EV_EOT", "EV_DADOS", "EV_DATA_SENT",
    "EV_NO_DATA", "EV_INVALID", "EV_MAX", "desconhecido"
};

const char* ST_NAMES[] = {"ST_INIT", "ST_WAIT_ACK", "ST_SENDING_DATA", "ST_RECEIVING_DATA",
                          "desconhecido"
};

estados g_state;
int g_session_over;

void processa_evento(event_t input)
{
    switch (g_state) {
    case ST_WAIT_ACK:
        switch (input) {
        case EV_TOUT_SOT:
            printf("Sot timeout. Reenviando SoT\n");
            send_sot();
            break;
        case EV_ACK:
            printf("Recebido EV_ACK.\n");
            timer_reset(&g_timer_mgr, SOT_TIMER_ID);
            if(has_message(&g_msg_mgr)) {                                 ///  A função has_message sempre retorna 0, sempre enviará eot?
                printf("Sending first data after ACK\n");
                send_first_data();
                g_state = ST_SENDING_DATA;
            } else {
                printf("No data, sending an EOT\n");
                send_eot();
                g_state = ST_RECEIVING_DATA;
            }
            break;
        default:
            printf("Em WaitACK recebeu e ignorou (%s)\n", EV_NAMES[input < EV_MAX ? input : EV_MAX]);
            break;
        }
        break;

    case ST_SENDING_DATA:
        switch (input) {
        case EV_TOUT_SESSION_TX:
            g_session_over = 1;
            break;
        case EV_DATA_SENT:
            if (g_session_over || !has_message(&g_msg_mgr)) {
                timer_reset(&g_timer_mgr, DOWNLINK_TIMER_ID);
                g_session_over = 0;
                send_eot();
                g_state = ST_RECEIVING_DATA;
            } else
                send_data();
            break;
        default:
            printf("Em ST_SENDING_DATA recebeu (%s)\n", EV_NAMES[input < EV_MAX ? input : EV_MAX]);
            break;
        }
        break;

    case ST_RECEIVING_DATA:
        switch (input) {
        case EV_TOUT_NO_RX:
            timer_reset(&g_timer_mgr, UPLINK_TIMER_ID);
            send_sot();
            g_state = ST_WAIT_ACK;
            break;
        case EV_EOT:
            if (has_message(&g_msg_mgr)) {                                       ///  A função has_message sempre retorna 0, sempre enviará eot?
                timer_reset(&g_timer_mgr, UPLINK_TIMER_ID);
                timer_reset(&g_timer_mgr, UPLINK_RX_TIMER_ID);
                send_first_data();
                g_state = ST_SENDING_DATA;
            } else
                send_eot();
            break;
        case EV_DADOS:
            processa_dados();
            break;
        case EV_TOUT_SESSION_RX:
            tout_rx_sessao();
            break;
        default:
            printf("Em ST_RECEIVING_DATA recebeu (%s)\n", EV_NAMES[input < EV_MAX ? input : EV_MAX]);
            break;
        }
        break;

    default:
        break;
    }

}


void init_sm()
{
    printf("Enviando SoT e inicializando SM\n");
    send_sot();
    g_state = ST_WAIT_ACK;
}
