#ifndef EVENT_LINUX_H
#define EVENT_LINUX_H

#include <semaphore.h>

struct event_manager_struct {
    event_t _event;
    sem_t _sync;
};

#endif /* EVENT_LINUX_H */
