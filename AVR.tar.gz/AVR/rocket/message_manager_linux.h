#ifndef MESSAGE_MANAGER_LINUX_H
#define MESSAGE_MANAGER_LINUX_H

struct message_manager_struct {
};

#endif /* MESSAGE_MANAGER_LINUX_H */
