#include <stdio.h>
#include <mqueue.h>
#include <errno.h>
#include <string.h>
#include <signal.h>

#include "sm_rocket.h"
#include "radio.h"
#include "event.h"


#define BUFFER_SIZE 50

char g_buffer[BUFFER_SIZE];

const char MQ_NAME_DOWN[] = "/rocket_down_mq2";
const char MQ_NAME_UP[] = "/rocket_up_mq2";

void mq_cb(union sigval value)
{
    if(mq_receive(g_radio._mq_up, g_buffer, sizeof(g_buffer), 0) == -1) {
        if(errno != EAGAIN || errno != EINTR) {
            perror("Receiving on message queues");
        }
    } else {
        if(strcmp(g_buffer, "ACK") == 0)
            event_post(&g_event_mgr, EV_ACK);
        else if(strcmp(g_buffer, "EOT") == 0)
            event_post(&g_event_mgr, EV_EOT);
        else
            event_post(&g_event_mgr, EV_DADOS);
    }

    struct sigevent sigev;
    sigev.sigev_notify = SIGEV_THREAD;
    sigev.sigev_value.sival_int = 0;
    sigev.sigev_notify_function = mq_cb;
    sigev.sigev_notify_attributes = 0;
    if(mq_notify(g_radio._mq_up, &sigev)) {
        perror("Registering a notify on message queues");
    }
}

int radio_init(radio_t* radio) {
    int rc = 0;
    
    /*if(mq_close(radio->_mq_down)) {
        perror("In radio_deinit(), on closing downlink queue");
        rc = 1;
    }
    if(mq_unlink(MQ_NAME_DOWN)) {
        perror("In radio_deinit(), on unlinking downlink queue");
        rc = 1;
    }*/                                                                     // coloquei no código para tirar erro resource temporalily unavaliable no message queue down
    
    struct mq_attr attr;
    attr.mq_msgsize = 30;
    attr.mq_maxmsg = 10;
    radio->_mq_down = mq_open(MQ_NAME_DOWN, O_RDWR | O_CREAT | O_NONBLOCK, S_IWUSR | S_IRUSR, &attr);
    if(radio->_mq_down == -1) {
        perror("Opening downlink message queues");
        rc = -1;
    }

    radio->_mq_up = mq_open(MQ_NAME_UP, O_RDWR | O_CREAT | O_NONBLOCK, S_IRUSR | S_IWUSR, &attr);
    if(radio->_mq_up == -1) {
        perror("Opening uplink message queues");
        rc = -1;
    }
    

    while(mq_receive(radio->_mq_up, g_buffer, sizeof(g_buffer), 0) > 0)        // por que chamar para receber aqui?
     {  
       printf("%s\n", g_buffer);
     }  

    struct sigevent sigev;
    sigev.sigev_notify = SIGEV_THREAD;
    sigev.sigev_value.sival_int = 0;
    sigev.sigev_notify_function = mq_cb;
    sigev.sigev_notify_attributes = 0;
    if(mq_notify(radio->_mq_up, &sigev)) {
        perror("Registering a notify on message queues");
        rc = -1;
    }

    return rc;
}

int radio_deinit(radio_t* radio) {
    int rc = 0;

    if(mq_close(radio->_mq_down)) {
        perror("In radio_deinit(), on closing downlink queue");
        rc = 1;
    }
    if(mq_unlink(MQ_NAME_DOWN)) {
        perror("In radio_deinit(), on unlinking downlink queue");
        rc = 1;
    }

    if(mq_close(radio->_mq_up)) {
        perror("In radio_deinit(), on closing uplink queue");
        rc = 1;
    }
    if(mq_unlink(MQ_NAME_DOWN)) {
        perror("In radio_deinit(), on unlinking uplink queue");
        rc = 1;
    }

    return rc;
}

int radio_send(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;

    if(mq_send(mgr->_mq_down, buffer, nbr_bytes, 0)) {
        perror("Sending SOT on message queue");
        rc = -1;
    }

    return rc;
}

int radio_receive(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;

    return rc;
}

void radio_make_silent(radio_t* mgr) {
}
