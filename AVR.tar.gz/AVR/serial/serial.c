#include <ch.h>
#include <hal.h>
#include <string.h>

#define LED_PAD PORTB_LED1
#define LED_PORT IOPORT2

static THD_WORKING_AREA(waThread1, 32);
static THD_FUNCTION(Thread1, arg);
void Thread1(void *arg)
{
    palTogglePad(LED_PORT, LED_PAD);

    while (true) {
        palTogglePad(LED_PORT, LED_PAD);
        chThdSleepMilliseconds(100);
    }
}

int main(void)
{
    
    const char msg[] = "hello, world";

    halInit();
    chSysInit();

    sdStart(&SD1, 0);


    palSetPadMode(IOPORT2, 2, PAL_MODE_OUTPUT_PUSHPULL);
    palClearPad(LED_PORT, LED_PAD);

    palSetPadMode(IOPORT4, 1, PAL_MODE_OUTPUT_PUSHPULL); //tx
    palSetPadMode(IOPORT4, 0, PAL_MODE_INPUT); //rx

    chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO+1, Thread1, NULL);

    while (1) {        
        sdWrite(&SD1, (const unsigned char*) msg, strlen(msg));
       
        chThdSleepMilliseconds(2000);
    }

    return 0;
}
