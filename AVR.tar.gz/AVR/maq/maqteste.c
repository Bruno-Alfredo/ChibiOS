/*
    ChibiOS - Copyright (C) 2006..2018 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#include "ch.h"
#include "hal.h"
#include "chprintf.h"
#include "event.h"
#include "sm.h"
#include "transitions.h"

enum {
        EVENT_A = USER_EVENT,                          //Evento A = Iniciar Ciclo de Lavagem
        EVENT_B,                                       //Evento B = Nível de Água Alto
        EVENT_C,                                       //Evento C = Timeout do Motor
        EVENT_D,                                       //Evento D = Toggle do Motor 1 e 2, se Estiver em Motor 1 desliga Motor 1 e Liga Motor 2 , e vice-versa
        EVENT_E,                                       //Evento E = Nível de Água Baixo
        EVENT_F,                                       //Evento F = Porta Aberta
        EVENT_G,                                       //Evento G = Porta Fechada
        EVENT_H,
        EVENT_I
};

uint8_t foo;

cb_status init_cb(event_t ev)
{
        foo = 0;
        //printf("top-INIT; ");
        Topo_init_tran();
        return EVENT_HANDLED;
}

cb_status S(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("s-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("s-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("s-INIT; ");
                S_init_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}
cb_status S1_Fechado(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Fechado-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Fechado-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("Fechado-INIT; ");
                S1_Fechado_init_tran();
                return EVENT_HANDLED;
        case EVENT_F:
                //printf("F-Fechado-Abrir; ");
                S1_Fechado_S2_Aberto_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}

cb_status S2_Aberto(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Aberto-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Aberto-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_G:
                //printf("G--Aberto-Fechar; ");
                S2_Fechado_S1_Aberto_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}

cb_status S11_Espera(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Espera-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Espera-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_A:
                //printf("A--Espera-iniciar; ");
                S11_Espera_S12_Molho_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}

cb_status S12_Molho(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Molho-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Molho-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("Molho-INIT; ");
                S12_Molho_init_tran();
                return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S121_AguaEntra(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("MolhoEntradaAgua-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("MolhoEntradaAgua-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_B:
        	    //printf("B--MolhoEntradaAgua-TanqueCheio; ");
        	    S121_AguaEntra_S122_Motor_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S122_Motor(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("MolhoMotor-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("MolhoMotor-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("MolhoMotor-INIT; ");
                S122_Motor_init_tran();
                return EVENT_HANDLED;        
        case EVENT_C:
        	    //printf("C--MolhoMotor-Timeout10s; ");
        	    S122_Motor_S13_Lavagem_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1221_Motor1(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("MolhoMotor1-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("MolhoMotor1-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--MolhoMotor1-TOGGLE; ");
        	    S1222_Motor1_S1222_Motor2_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1222_Motor2(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("MolhoMotor2-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("MolhoMotor2-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--MolhoMotor2-TOGGLE; ");
        	    S1222_Motor2_S1222_Motor1_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S13_Lavagem(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Lavagem-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Lavagem-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("Lavagem-INIT; ");
                S13_Lavagem_init_tran();
                return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S131_Motor(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("LavagemMotor-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("LavagemMotor-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("LavagemMotor-INIT; ");
                S131_Motor_init_tran();
                return EVENT_HANDLED;
        case EVENT_C:  
		        //printf("C--LavagemMotor-Timeout12s; ");
        	    S131_Motor_S132_AguaSaida_tran();
        	    return EVENT_HANDLED;      
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1311_Motor1(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("LavagemMotor1-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("LavagemMotor1-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--LavagemMotor1-TOGGLE; ");
        	    S1311_Motor1_S1312_Motor2_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1312_Motor2(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("LavagemMotor2-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("LavagemMotor2-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--LavagemMotor2-TOGGLE; ");
        	    S1312_Motor2_S1311_Motor1_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S132_AguaSaida(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("LavagemSaidaAgua-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("LavagemSaidaAgua-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_E:
        	    //printf("E--LavagemSaidaAgua-TanqueBaixo; ");
        	    S132_AguaSaida_S14_Enxague_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S14_Enxague(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
               // //printf("Enxague-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               // //printf("Enxague-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
               // //printf("Enxague-INIT; ");
                S14_Enxague_init_tran();
                return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S141_AguaEntra(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
               // //printf("EnxagueEntradaAgua-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               // //printf("EnxagueEntradaAgua-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_B:
        	  //  //printf("B--EnxagueEntradaAgua-TanqueAlto; ");
        	    S141_AguaEntra_S142_Motor_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S142_Motor(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                ////printf("EnxagueMotor-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               // //printf("EnxagueMotor-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                ////printf("EnxagueMotor-INIT; ");
                S142_Motor_init_tran();
                return EVENT_HANDLED;        
        case EVENT_C:
        	 //   //printf("C--EnxagueMotor-Timeout15s; ");
        	    S142_Motor_S143_AguaSaida_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1421_Motor1(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
               // //printf("EnxagueMotor1-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               // //printf("EnxagueMotor1-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	  //  //printf("D--EnxagueMotor1-TOGGLE; ");
        	    S1421_Motor1_S1422_Motor2_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1422_Motor2(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                ////printf("EnxagueMotor2-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                ////printf("EnxagueMotor2-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	  //  //printf("D--EnxagueMotor2-TOGGLE; ");
        	    S1422_Motor2_S1421_Motor1_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S143_AguaSaida(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                ////printf("EnxagueSaidaAgua-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                ////printf("EnxagueSaidaAgua-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_E:
        	  //  //printf("E--EnxagueSaidaAgua-TanqueBaixo; ");
        	    S143_AguaSaida_S15_Centrifugacao_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S15_Centrifugacao(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                ////printf("Centrifugacao-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               // //printf("Centrifugacao-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_C:
              //  //printf("C--Centrifugacao-Timeout20s; ");
                S15_Centrifugacao_S11_Espera_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}



thread_t *p_main_thread;


static THD_WORKING_AREA(waThread1, 32);
static THD_FUNCTION(Thread1, arg) {

  (void)arg;
  chRegSetThreadName("Blinker");
  while (true) {
    palTogglePad(IOPORT2, PORTB_LED1);
    chEvtSignal(p_main_thread, EVENT_MASK(0));
    chThdSleepMilliseconds(250);
  }
}

#define NBR_CHANNELS 3
#define DEPTH 5

volatile uint8_t flag;

/*
 * Application entry point.
 */

int main(void) {

  /*
   * System initializations.
   * - HAL initialization, this also initializes the configured device drivers
   *   and performs the board-specific initializations.
   * - Kernel initialization, the main() function becomes a thread and the
   *   RTOS is active.
   */
  halInit();
  chSysInit();

  p_main_thread = chThdGetSelfX();
  /*
   * Activates the serial driver 1 using the driver default configuration.
   */
  sdStart(&SD1, NULL);

  /*
   * 
   */
 
  /*
   * Starts the LED blinker thread.
   */
  chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO, Thread1, NULL);

  chnWrite(&SD1, (const uint8_t *)"Hello !\r\nWorld", 14);
  while(TRUE) {
      
       chnWrite(&SD1, (const uint8_t *)"Hello !\r\nWorld", 14);
      chEvtWaitOne (EVENT_MASK(0));
      flag =0;
  /*    for(int i=0; i<DEPTH; i++)
          ch//printf((BaseSequentialStream *)&SD1, "%d %d %d\n", buffer[i*NBR_CHANNELS], buffer[i*NBR_CHANNELS + 1], buffer[i*NBR_CHANNELS + 2]);*/
      chThdSleepMilliseconds(50);
  }
}
