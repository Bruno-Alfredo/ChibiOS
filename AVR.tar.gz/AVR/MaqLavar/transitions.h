#ifndef TRANSITIONS_H
#define TRANSITIONS_H

#include "event.h"
#include "sm.h"


cb_status S(event_t ev);
cb_status S1_Fechado(event_t ev);
cb_status S2_Aberto(event_t ev);
cb_status S11_Espera(event_t ev);
cb_status S12_Molho(event_t ev);
cb_status S121_AguaEntra(event_t ev);
cb_status S122_Motor(event_t ev);
cb_status S1221_Motor1(event_t ev);
cb_status S1222_Motor2(event_t ev);
cb_status S13_Lavagem(event_t ev);
cb_status S131_Motor(event_t ev);
cb_status S1311_Motor1(event_t ev);
cb_status S1312_Motor2(event_t ev);
cb_status S132_AguaSaida(event_t ev);
cb_status S14_Enxague(event_t ev);
cb_status S141_AguaEntra(event_t ev);
cb_status S142_Motor(event_t ev);
cb_status S1421_Motor1(event_t ev);
cb_status S1422_Motor2(event_t ev);
cb_status S143_AguaSaida(event_t ev);
cb_status S15_Centrifugacao(event_t ev);



#define Topo_init_tran() do {                   \
                push_state(S);                  \
                dispatch(ENTRY_EVENT);          \
                push_state(S1_Fechado);         \
                dispatch(ENTRY_EVENT);          \
                push_state(S11_Espera);         \
                dispatch(ENTRY_EVENT);          \
        } while (0)
        
#define S_init_tran() do {                      \
                push_state(S1_Fechado);         \
                dispatch(ENTRY_EVENT);          \
        } while (0)
        
#define S1_Fechado_init_tran() do {              \
                push_state(S11_Espera);         \
                dispatch(ENTRY_EVENT);          \
        } while (0)        

#define S1_Fechado_S2_Aberto_tran() do {        \
                exit_inner_states();            \
                dispatch(EXIT_EVENT);           \
                replace_state(S2_Aberto);       \
                dispatch(ENTRY_EVENT);          \
        } while (0)
        
#define S2_Fechado_S1_Aberto_tran() do {        \
                dispatch(EXIT_EVENT);           \
                replace_state(S1_Fechado);       \
                dispatch(ENTRY_EVENT);          \
                dispatch(INIT_EVENT);            \
        } while (0)        

#define S11_Espera_S12_Molho_tran() do {        \
                dispatch(EXIT_EVENT);           \
                replace_state(S12_Molho);       \
                dispatch(ENTRY_EVENT);          \
                dispatch(INIT_EVENT);            \
        } while (0)    

#define S12_Molho_init_tran() do {              \
                push_state(S121_AguaEntra);      \
                dispatch(ENTRY_EVENT);          \
        } while (0)  

#define S121_AguaEntra_S122_Motor_tran() do {   \
                dispatch(EXIT_EVENT);           \
                replace_state(S122_Motor);       \
                dispatch(ENTRY_EVENT);          \
                dispatch(INIT_EVENT);            \
        } while (0)    

#define S122_Motor_init_tran() do {              \
                push_state(S1221_Motor1);      \
                dispatch(ENTRY_EVENT);          \
        } while (0)

#define S122_Motor_S13_Lavagem_tran() do {      \
                exit_inner_states();            \
                dispatch(EXIT_EVENT);           \
                pop_state();                    \
                dispatch(EXIT_EVENT);           \
                replace_state(S13_Lavagem);      \
                dispatch(ENTRY_EVENT);          \
                dispatch(INIT_EVENT);            \
        } while (0)    

#define S1222_Motor1_S1222_Motor2_tran() do {   \
                dispatch(EXIT_EVENT);           \
                replace_state(S1222_Motor2);     \
                dispatch(ENTRY_EVENT);          \
        } while (0)   
		 
#define S1222_Motor2_S1222_Motor1_tran() do {   \
                dispatch(EXIT_EVENT);           \
                replace_state(S1221_Motor1);     \
                dispatch(ENTRY_EVENT);          \
        } while (0)    

#define S13_Lavagem_init_tran() do {              \
                push_state(S131_Motor);           \
                dispatch(ENTRY_EVENT);          \
                dispatch(INIT_EVENT);            \
        } while (0)
        
#define S131_Motor_init_tran() do {              \
                push_state(S1311_Motor1);        \
                dispatch(ENTRY_EVENT);           \
        } while (0)        

#define S131_Motor_S132_AguaSaida_tran() do {    \
                exit_inner_states();            \
                dispatch(EXIT_EVENT);           \
                replace_state(S132_AguaSaida);    \
                dispatch(ENTRY_EVENT);          \
        } while (0)    
        
#define S1311_Motor1_S1312_Motor2_tran() do {   \
                dispatch(EXIT_EVENT);           \
                replace_state(S1312_Motor2);     \
                dispatch(ENTRY_EVENT);          \
        } while (0)        

#define S1312_Motor2_S1311_Motor1_tran() do {   \
                dispatch(EXIT_EVENT);           \
                replace_state(S1311_Motor1);     \
                dispatch(ENTRY_EVENT);          \
        } while (0)

#define S132_AguaSaida_S14_Enxague_tran() do {      \
                dispatch(EXIT_EVENT);           \
                pop_state();                    \
                dispatch(EXIT_EVENT);           \
                replace_state(S14_Enxague);      \
                dispatch(ENTRY_EVENT);          \
                dispatch(INIT_EVENT);            \
        } while (0)    

#define S14_Enxague_init_tran() do {              \
                push_state(S141_AguaEntra);       \
                dispatch(ENTRY_EVENT);          \
        } while (0)

#define S141_AguaEntra_S142_Motor_tran() do {   \
                dispatch(EXIT_EVENT);           \
                replace_state(S142_Motor);       \
                dispatch(ENTRY_EVENT);          \
                dispatch(INIT_EVENT);            \
        } while (0)    

#define S142_Motor_init_tran() do {              \
                push_state(S1421_Motor1);      \
                dispatch(ENTRY_EVENT);          \
        } while (0)

#define S142_Motor_S143_AguaSaida_tran() do {     \
                exit_inner_states();              \
                dispatch(EXIT_EVENT);             \
                replace_state(S143_AguaSaida);    \
                dispatch(ENTRY_EVENT);            \
        } while (0)   

#define S1421_Motor1_S1422_Motor2_tran() do {     \
                dispatch(EXIT_EVENT);             \
                replace_state(S1422_Motor2);      \
                dispatch(ENTRY_EVENT);            \
        } while (0)        

#define S1422_Motor2_S1421_Motor1_tran() do {     \
                dispatch(EXIT_EVENT);             \
                replace_state(S1421_Motor1);      \
                dispatch(ENTRY_EVENT);            \
        } while (0)

#define S143_AguaSaida_S15_Centrifugacao_tran() do {   \
                dispatch(EXIT_EVENT);                  \
                pop_state();                           \
                dispatch(EXIT_EVENT);                  \
                replace_state(S15_Centrifugacao);      \
                dispatch(ENTRY_EVENT);                 \
        } while (0)    

#define S15_Centrifugacao_S11_Espera_tran() do {     \
                dispatch(EXIT_EVENT);                \
                replace_state(S11_Espera);           \
                dispatch(ENTRY_EVENT);               \
        } while (0) 


#endif /* TRANSITIONS_H */
