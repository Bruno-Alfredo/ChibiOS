#ifndef SM_BASE_H
#define SM_BASE_H


typedef enum {
    ST_INIT = 0, ST_WAIT_SOT, ST_WAIT_DATA, ST_SEND_DATA
} estados;

typedef enum {
 EV_ACK = 0, EV_SOT, EV_TOUT_SOT, EV_TOUT, EV_EOT, EV_EOT_BASE, EV_DATA_RECEIVED,
    EV_SEND_DATA_ROCKET,EV_SEND_DATA_BASE, EV_TOUT_NO_RX, EV_NO_DATA, EV_TOUT_SESSAO,
    EV_INVALID, EV_MAX
} eventos;



extern estados g_state;

void init_sm();
int processa_sot();
void processa_tout_sot();
void processa_tout();
void processa_eot_base();
void processa_eot_rocket();
void processa_send_data();
void processa_no_data();
void processa_send_data_base();
void processa_send_data_base_begin();
void processa_dados();
void tout_sessao();
void unexpected_sot();

void processa_evento(eventos input);

#endif /* SM_BASE_H */
