#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <mqueue.h>
#include <semaphore.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <string.h>

#include "sm_base.h"


eventos g_input = EV_INVALID;

                                                           // na compilação rocket apareceu message queue: Resource temporarily unavailable 
sem_t g_sem;
mqd_t g_mq1, g_mq2;       
timer_t g_timer1, g_timer2;
const char MQ_NAME_UP[] = "/rocket_up_mq2";
const char MQ_NAME_DOWN[] = "/rocket_down_mq2";

void send_ack()
{
    const char ack[] = "ACK";
    if(mq_send(g_mq2, ack, sizeof(ack), 0)) {
        perror("Sending SOT on message queue");              // sending ACK?
        exit(-1);
    }
}

void send_eot()
{
    const char eot[] = "EOT";
    if(mq_send(g_mq2, eot, sizeof(eot), 0)) {
        perror("Sending SOT on message queue");
        exit(-1);
    }
}

void timer_cb(union sigval value)
{
    switch(value.sival_int) {
    case 0:
        printf("Timer1: Don't know what to do\n");
        break;
    case 1:
        printf("Timer2: Don't know what to do\n");
        break;
    default:
        printf("Unknown timer set off.  Aborting...\n");
        exit(-1);
    }
}

void setup_timers()
{
    struct sigevent sigev;
    sigev.sigev_notify = SIGEV_THREAD;
    sigev.sigev_value.sival_int = 0;   // Valor a ser passado para o cb quando este for chamado
    sigev.sigev_notify_function = timer_cb;
    sigev.sigev_notify_attributes = 0;
    if(timer_create(CLOCK_REALTIME, &sigev, &g_timer1)) {
        perror("Timer1 creation");
        exit(-1);
    }
    sigev.sigev_value.sival_int = 1;   // Valor a ser passado para o cb quando este for chamado
    if(timer_create(CLOCK_REALTIME, &sigev, &g_timer2)) {
        perror("Timer2 creation");
        exit(-1);
    }
}

char g_buffer[30];
void mq_cb(union sigval value)
{
    if(mq_receive(g_mq1, g_buffer, sizeof(g_buffer), 0) == -1) {
        if(errno != EAGAIN || errno != EINTR) {
            perror("On receiving on message queues in mq_cb");
            return;
        }
    } else {
        if(strcmp(g_buffer, "SOT") == 0) {
            printf("Receiving an SOT\n");                                       // não seria Receiving a SOT?
            g_input = EV_SOT;
        } else if(strcmp(g_buffer, "EOT") == 0) {
            printf("Receiving an EOT\n");
            g_input = EV_EOT;
        } else
            fprintf(stderr, "Unknown message received...\n");
    }

    struct sigevent sigev;
    sigev.sigev_notify = SIGEV_THREAD;
    sigev.sigev_value.sival_int = 0;
    sigev.sigev_notify_function = mq_cb;
    sigev.sigev_notify_attributes = 0;
    if(mq_notify(g_mq1, &sigev)) {
        perror("Registering a notify on message queues");
        exit(-1);
    }

    sem_post(&g_sem);
}

void setup_msgqueue()
{

    struct mq_attr attr;
    attr.mq_msgsize = 30;
    attr.mq_maxmsg = 10;
    
    g_mq1 = mq_open(MQ_NAME_DOWN, O_RDWR | O_CREAT | O_NONBLOCK, S_IRUSR | S_IWUSR, &attr);                     // por que 0? não deveria ser &attr,  adicionei | O_CREAT e funcionou
    if(g_mq1 == -1) {
        perror("Opening downlink message queues");
        exit(-1);
    }

    g_mq2 = mq_open(MQ_NAME_UP, O_RDWR | O_CREAT | O_NONBLOCK, S_IRUSR | S_IWUSR, &attr);
    if(g_mq2 == -1) {
        perror("Opening uplink message queues");
        exit(-1);
    }
 //   while(mq_receive(g_mq1, g_buffer, sizeof(g_buffer), 0) > 0)        // por que chamar para receber aqui?
  //      ;
    while(mq_receive(g_mq1, g_buffer, sizeof(g_buffer), 0) > 0)        // por que chamar para receber aqui?
        ;
    struct sigevent sigev;
    sigev.sigev_notify = SIGEV_THREAD;
    sigev.sigev_value.sival_int = 0;
    sigev.sigev_notify_function = mq_cb;
    sigev.sigev_notify_attributes = 0;
    if(mq_notify(g_mq1, &sigev)) {
        perror("Registering a notify on message queues");
        exit(-1);
    }
}

void setup_all()
{
    setup_msgqueue();
    setup_timers();
}

void stop_timers()
{
    if(timer_delete(g_timer1))  {
        perror("Destroying timer1");
        exit(-1);
    }
    if(timer_delete(g_timer2))  {
        perror("Destroying timer2");
        exit(-1);
    }
}

void stop_msgqueue()
{
    if(mq_close(g_mq1)) {
        perror("Message queues");
        exit(-1);
    }
    if(mq_unlink(MQ_NAME_DOWN)) {
        perror("Message queues");
        exit(-1);
    }
}

void stop_all()
{
    stop_msgqueue();
    stop_timers();
}

void start_timer_session()
{
}

// inicio codigo novo
void init_sm()
{
    printf (" 'esperando por SOT' \n ");
    g_state = ST_WAIT_SOT;
}

void tout_sessao()
{
    printf (" 'estouro no tempo de sessão' \n");
}

void unexpected_sot() {
}

void cancela_timer(timer_t timer)                      // não há a função set_timer???
{
    struct itimerspec spec;  
    spec.it_interval.tv_sec = 0;
    spec.it_interval.tv_nsec = 0;
    spec.it_value.tv_sec = 0;
    spec.it_value.tv_nsec = 0;

    if(timer_settime(timer, 0, &spec, 0)) {
        perror("Disarming timer");
        exit(-1);
    }
}

int rnd;
int processa_sot()
{
    cancela_timer(g_timer1);
    send_ack();
}

void processa_dados()
{
    printf(" 'continua a receber dados' \n");
}
void processa_send_data_base_begin() 
{
    printf(" ' dados recebidos, transicao para o enviar dados ' \n");
    /* Mandando um EOT por enquanto só para testar o foguete */
    const char msg[] = "EOT";
    if(mq_send(g_mq2, msg, sizeof(msg), 0)) {
        perror("Sending EOT on message queue");
        exit(-1);
    }
}
void processa_send_data_base()
{
    printf(" 'continua a enviar dados da base' \n");
}
void processa_send_data()
{
    printf(" 'continua a enviar dados da base' \n");
    const char msg[] = "DATA";
    if(mq_send(g_mq2, msg, sizeof(msg), 0)) {
        perror("On sending data on message queue in processa_send_data()");
        exit(-1);
    }
}
void processa_tout()
{
    printf(" estouro no tempo, transicao para 'esperando dados' \n ");
}
void processa_eot_base()
{
    printf(" transicao para o estado 'esperando dados' \n");
}
// fim!!!!



int main(void)
{
    setup_all();
    init_sm();

    while (1) {
        if(sem_wait(&g_sem)) {  //       sem_wait() decrements (locks) the semaphore pointed to by sem.  If
                                       //       the semaphore's value is greater than zero, then the decrement
                                //       proceeds, and the function returns, immediately.  If the semaphore
                                //       currently has the value zero, then the call blocks until either it
                                //       becomes possible to perform the decrement (i.e., the semaphore value
                                //       rises above zero), or a signal handler interrupts the call.
            if(errno == EINTR)
                continue;
            else {
                perror("Semaphore wait");
                break;
            }
        }
        // como faz para corrigir o problema de ter dois processos ocorrendo ao mesmo tempo? lembro que precisava de dois semáforos (ou dois sem_wait)
        // como faz a estrutura desses dois semáforos em paralelo?
        processa_evento(g_input);
        g_input = EV_INVALID;
    }

    stop_all();
    return 0;
}
