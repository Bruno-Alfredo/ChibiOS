#include "ch.h"
#include "hal.h"

#include <stdio.h>
#include <stdlib.h>

#include "sm_rocket.h"
#include "event.h"
#include "timer_manager.h"
#include "chvt.h"

timer_manager_t g_timer_mgr;
message_manager_t g_msg_mgr;
radio_t g_radio;
event_manager_t g_event_mgr;


/*
void my_timer_cb(uint8_t event) {
    event_post(&g_event_mgr, event);
}  */

void setup_all()
{
  /*  if (timer_init_manager(&g_timer_mgr, 2, my_timer_cb)) {
        printf("Error creating timers.  Aborting program!\n");
        exit(-1);
    } */
    if (event_init_manager(&g_event_mgr)) {
      //  printf("Error creating event manager.  Aborting program!\n");
       // exit(-1);
    }
    if (radio_init(&g_radio)) {
     //   printf("Error creating radio.  Aborting program!\n");
     //   exit(-1);
    }
  /*  if (message_init_manager(&g_msg_mgr)) {
        printf("Error creating message manager.  Aborting program!\n");
        exit(-1);
    }  */
}

void stop_all()
{
 /*   event_deinit_manager(&g_event_mgr);
    if (timer_deinit_manager(&g_timer_mgr))
        printf("Error destroying timers.\n");  */
}

/*
static THD_WORKING_AREA(waThread2, 32);
static THD_FUNCTION(Thread2, arg) {

  (void)arg;
  chRegSetThreadName("Thread2");
 
        while (1) {

       
            event_post(&g_event_mgr, EV_ACK);
            chThdSleepMilliseconds(1000);
            
            event_post(&g_event_mgr, EV_EOT);
            chThdSleepMilliseconds(1000);
            
            event_post(&g_event_mgr, EV_DADOS);
            chThdSleepMilliseconds(1000);
        }
}*/

int main(void)
{
    halInit();
    chSysInit();

    setup_all();
    chVTObjectInit(&vt_obj1);
    chVTObjectInit(&vt_obj2);
    chVTObjectInit(&vt_obj3);
    init_sm();
  //  chThdCreateStatic(waThread2, sizeof(waThread2), NORMALPRIO, Thread2, NULL);      //thread criada para enviar eventos e testar serial

    while (1) {
        event_t ev = event_wait(&g_event_mgr);
     //   printf("Evento recebido = %u\n", ev);
        if (ev != EV_INVALID)
            processa_evento(ev);
      //  else
       //     printf("Recebido evento inválido!\n");
    }

    stop_all();

    return 0;
}
