#include "ch.h"
#include "hal.h"

#include <stdio.h>
#include <string.h>

#include "sm_rocket.h"
#include "radio.h"
#include "event.h"


#define BUFFER_SIZE 3

#define LED_PAD PORTB_LED1
#define LED_PORT IOPORT2

char g_buffer[BUFFER_SIZE];
uint8_t g_buffer1[0];

const char MQ_NAME_DOWN[] = "/rocket_down_mq2";
const char MQ_NAME_UP[] = "/rocket_up_mq2";

static const SPIConfig spiCfg = {
  NULL,                         /* SPI callback.                  */
  IOPORT2,                      /* SPI chip select port.          */
  SPI1_SS,                            /* SPI chip select pad.           */
  SPI_CR_DORD_MSB_FIRST     |   /* SPI Data order.                */
  SPI_CR_CPOL_CPHA_MODE(0)  |   /* SPI clock polarity and phase.  */
  SPI_CR_SCK_FOSC_128,          /* SPI clock.                     */
  SPI_SR_SCK_FOSC_2,             /* SPI double speed bit.          */
  SPI_ROLE_MASTER
};


static THD_WORKING_AREA(waThread1, 32);
static THD_FUNCTION(Thread1, arg) {

  (void)arg;
  chRegSetThreadName("Thread1");
 
        while (1) {
           sdRead(&SD1, g_buffer1, 1);     // buffer[0] =='E' 'A'   buffer[3] =0;

           if(g_buffer1[0] == 'A') {
              event_post(&g_event_mgr, EV_ACK);
        } else if(g_buffer1[0] == 'E') {
              event_post(&g_event_mgr, EV_EOT);
        } else {
            event_post(&g_event_mgr, EV_DADOS);
                //        palTogglePad(LED_PORT, LED_PAD);
        }
        chThdSleepMilliseconds(200);
        }
}
// TIME_S2i mS2I uS2I I2S
int radio_init(radio_t* radio) {
    int rc = 0;
    sdStart(&SD1, NULL);
    chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO, Thread1, NULL);
    
    

    while(mq_receive(radio->_mq_up, g_buffer, sizeof(g_buffer), 0) > 0)        // por que chamar para receber aqui?
     {  
       printf("%s\n", g_buffer);
     }  

    struct sigevent sigev;
    sigev.sigev_notify = SIGEV_THREAD;
    sigev.sigev_value.sival_int = 0;
    sigev.sigev_notify_function = mq_cb;
    sigev.sigev_notify_attributes = 0;
    if(mq_notify(radio->_mq_up, &sigev)) {
        perror("Registering a notify on message queues");
        rc = -1;
    }   */
     
    return rc;
}

int radio_deinit(radio_t* radio) {
    int rc = 0;

    return rc;
}

int radio_send(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;
    sdWrite(&SD1, (const uint8_t*) buffer, nbr_bytes);
    spiSelect(&SPID1);
    spiSend(&SPID1, nbr_bytes , (const uint8_t*) buffer);
    spiUnselect(&SPID1);
    return rc;
}

int radio_receive(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;

    return rc;
}

void radio_make_silent(radio_t* mgr) {
}
