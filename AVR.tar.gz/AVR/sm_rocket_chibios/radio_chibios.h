#ifndef RADIO_CHIBIOS_H
#define RADIO_CHIBIOS_H

//#include <mqueue.h>


struct radio_struct {
   // mqd_t _mq_down;
   // mqd_t _mq_up;
};

#endif /* RADIO_CHIBIOS_H */
