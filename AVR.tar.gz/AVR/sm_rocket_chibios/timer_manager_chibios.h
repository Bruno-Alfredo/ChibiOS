#ifndef TIMER_MANAGER_CHIBIOS
#define TIMER_MANAGER_CHIBIOS


#define MAX_NBR_TIMERS 3

struct timer_cb_arg_struct {
    uint8_t _event;
    timer_cb_t _cb;
};

typedef struct timer_cb_arg_struct timer_cb_arg_t;

struct timer_manager_struct {
    int _nbr_timers;
  //  timer_t _timers[MAX_NBR_TIMERS];
    timer_cb_arg_t _args[MAX_NBR_TIMERS];
};

#endif /* TIMER_MANAGER_CHIBIOS */
