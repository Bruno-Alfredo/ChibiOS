#ifndef EVENT_H
#define EVENT_H

#include <stdint.h>

enum {
    EV_INVALID = 0, EV_USER
};

typedef uint8_t event_t;

typedef struct event_manager_struct event_manager_t;

int event_init_manager(event_manager_t *);
int event_deinit_manager(event_manager_t *);
void event_post(event_manager_t *, event_t);
event_t event_wait(event_manager_t *);
void event_purge(event_manager_t *, event_t);
/*
#ifdef __linux__
#include "event_linux.h"
#elif defined __AVR__  */
#include "event_chibios.h"
//#endif

#endif /* EVENT_H */
