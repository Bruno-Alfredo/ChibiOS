#ifndef MESSAGE_MANAGER_CHIBIOS_H
#define MESSAGE_MANAGER_CHIBIOS_H

struct message_manager_struct {
};

#endif /* MESSAGE_MANAGER_CHIBIOS_H */
