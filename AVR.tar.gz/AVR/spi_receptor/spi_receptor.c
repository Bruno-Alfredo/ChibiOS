
#include "ch.h"
#include "hal.h"


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


#define LED_PAD PORTB_LED1
#define LED_PORT IOPORT2

uint8_t g_buffer[3];                                          

 semaphore_t g_sem;

static const SPIConfig spiCfg = {
  NULL,                         /* SPI callback.                  */
  IOPORT2,                      /* SPI chip select port.          */
  SPI1_SS,                            /* SPI chip select pad.           */
  SPI_CR_DORD_MSB_FIRST     |   /* SPI Data order.                */
  SPI_CR_CPOL_CPHA_MODE(0)  |   /* SPI clock polarity and phase.  */
  SPI_CR_SCK_FOSC_128,          /* SPI clock.                     */
  SPI_SR_SCK_FOSC_2,             /* SPI double speed bit.          */
  SPI_ROLE_SLAVE
};


static THD_WORKING_AREA(waThread1, 32);
static THD_FUNCTION(Thread1, arg) {

  (void)arg;
  chRegSetThreadName("Thread1");
 
        while (1) {     
                                                                     
        //   sdRead(&SD1, g_buffer, 1);
           spiReceive(&SPID1, 3, (const uint8_t*) g_buffer);
           if(g_buffer[0] == 'E') {
          //  printf("Receiving an ACK\n"); 
            palTogglePad(IOPORT2, 0);        

        } else if(g_buffer[0] == 'A') {
          //  printf("Receiving an EOT\n");
           palTogglePad(IOPORT2, 0);                                   

        } else {  //palTogglePad(IOPORT2, 1); 

        }
         //   fprintf(stderr, "Unknown message received...\n");
            chThdSleepMilliseconds(500);

        }
}

/*
void send_ack()
{
    const char ack[] = "ACK";
    sdWrite(&SD1, (const uint8_t*) ack, strlen(ack));
    spiSelect(&SPID1);
    spiSend(&SPID1, strlen(ack), (const uint8_t*) ack);
    spiUnselect(&SPID1);
 
}
*/

int main(void)
{
    halInit();
    chSysInit();

    
    sdStart(&SD1, NULL);
    spiStart(&SPID1, &spiCfg);
    
    palSetPadMode(IOPORT2, 0, PAL_MODE_OUTPUT_PUSHPULL);
    palSetPadMode(IOPORT2, 1, PAL_MODE_OUTPUT_PUSHPULL);

    palSetPadMode(IOPORT2, SPI1_SS, PAL_MODE_INPUT);              //2
    palSetPadMode(IOPORT2, SPI1_MOSI, PAL_MODE_INPUT);            //3
    palSetPadMode(IOPORT2, SPI1_MISO, PAL_MODE_OUTPUT_PUSHPULL);                      //4
    palSetPadMode(IOPORT2, SPI1_SCK, PAL_MODE_INPUT);             //5
    
    palClearPad(IOPORT2, 0);
    palClearPad(IOPORT2, 1);
    

    chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO, Thread1, NULL);
    
    while (1) {
                 
       
       // palTogglePad(LED_PORT, LED_PAD);                              
         chThdSleepMilliseconds(2000);
         palTogglePad(IOPORT2, 1);
    }

    stop_all();
    spiStop(&SPID1);
    return 0;
}


