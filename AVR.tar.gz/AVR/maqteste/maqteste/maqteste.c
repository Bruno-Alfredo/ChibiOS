/*
    ChibiOS - Copyright (C) 2006..2018 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#include "ch.h"
#include "hal.h"
#include "chprintf.h"
#include "event.h"
#include "sm.h"
#include "transitions.h"
#include "chvt.h"


enum {
        EVENT_A = USER_EVENT,                          //Evento A = Iniciar Ciclo de Lavagem
        EVENT_B,                                       //Evento B = Nível de Água Alto
        EVENT_C,                                       //Evento C = Timeout do Motor
        EVENT_D,                                       //Evento D = Toggle do Motor 1 e 2, se Estiver em Motor 1 desliga Motor 1 e Liga Motor 2 , e vice-versa
        EVENT_E,                                       //Evento E = Nível de Água Baixo
        EVENT_F,                                       //Evento F = Porta Aberta/Fechada
        EVENT_G,                                       
        EVENT_H,
        EVENT_I
};

uint8_t foo;

 virtual_timer_t vt_obj;
 virtual_timer_t vt_obj1;

void cb(void *arg)
{
        set_event(EVENT_C);

}

void cb1(void *arg)
{
        set_event(EVENT_D);

}


cb_status init_cb(event_t ev)
{
        foo = 0;
        //printf("top-INIT; ");
        chnWrite(&SD1, (const uint8_t *)"top-INIT; ", 11);
        Topo_init_tran();
        return EVENT_HANDLED;
}

cb_status S(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("s-ENTRY; ");
                chnWrite(&SD1, (const uint8_t *)"s-ENTRY; ", 10);
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("s-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("s-INIT; ");
                S_init_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}
cb_status S1_Fechado(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Fechado-ENTRY; ");
                chnWrite(&SD1, (const uint8_t *)"Fechado-ENTRY; ", 16);
                return EVENT_HANDLED;
        case EXIT_EVENT:
                palClearPad(IOPORT2, 0);
                //printf("Fechado-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("Fechado-INIT; ");
                chnWrite(&SD1, (const uint8_t *)"Fechado-INIT; ", 15);
                S1_Fechado_init_tran();
                return EVENT_HANDLED;
        case EVENT_F:
                //printf("F-Fechado-Abrir; ");
                S1_Fechado_S2_Aberto_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}

cb_status S2_Aberto(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Aberto-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Aberto-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_F:
                //printf("G--Aberto-Fechar; ");
                S2_Fechado_S1_Aberto_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}

cb_status S11_Espera(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Espera-ENTRY; ");
                palClearPad(IOPORT2, 0);
                chnWrite(&SD1, (const uint8_t *)"Espera-ENTRY; ", 15);
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Espera-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_A:
                //printf("A--Espera-iniciar; ");
                palSetPad(IOPORT2, 0);
                S11_Espera_S12_Molho_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}

cb_status S12_Molho(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Molho-ENTRY; ");
                palSetPad(IOPORT3, 1);
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Molho-EXIT; ");
                palClearPad(IOPORT3, 1);
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("Molho-INIT; ");
                S12_Molho_init_tran();
                return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S121_AguaEntra(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("MolhoEntradaAgua-ENTRY; ");
                palSetPad(IOPORT2, 2);
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("MolhoEntradaAgua-EXIT; ");
                palClearPad(IOPORT2, 2);
                return EVENT_HANDLED;
        case EVENT_B:
        	    //printf("B--MolhoEntradaAgua-TanqueCheio; ");
        	    S121_AguaEntra_S122_Motor_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S122_Motor(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj, TIME_S2I(1), cb, (void *)&vt_obj);
                //printf("MolhoMotor-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("MolhoMotor-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("MolhoMotor-INIT; ");
                S122_Motor_init_tran();
                return EVENT_HANDLED;        
        case EVENT_C:
        	    //printf("C--MolhoMotor-Timeout10s; ");
        	    S122_Motor_S13_Lavagem_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1221_Motor1(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj1, TIME_MS2I(120), cb1, (void *)&vt_obj1);
                palSetPad(IOPORT4, 2);
                //printf("MolhoMotor1-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                palClearPad(IOPORT4, 2);
                //printf("MolhoMotor1-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--MolhoMotor1-TOGGLE; ");
        	    S1222_Motor1_S1222_Motor2_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1222_Motor2(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj1, TIME_MS2I(120), cb1, (void *)&vt_obj1);
                palSetPad(IOPORT4, 3);
                //printf("MolhoMotor2-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                palClearPad(IOPORT4, 3);
                //printf("MolhoMotor2-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--MolhoMotor2-TOGGLE; ");
        	    S1222_Motor2_S1222_Motor1_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S13_Lavagem(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("Lavagem-ENTRY; ");
                palSetPad(IOPORT3, 2);
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("Lavagem-EXIT; ");
                palClearPad(IOPORT3, 2);
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("Lavagem-INIT; ");
                S13_Lavagem_init_tran();
                return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S131_Motor(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj, TIME_S2I(5), cb, (void *)&vt_obj);
                //printf("LavagemMotor-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("LavagemMotor-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                //printf("LavagemMotor-INIT; ");
                S131_Motor_init_tran();
                return EVENT_HANDLED;
        case EVENT_C:  
		        //printf("C--LavagemMotor-Timeout12s; ");
        	    S131_Motor_S132_AguaSaida_tran();
        	    return EVENT_HANDLED;      
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1311_Motor1(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj1, TIME_MS2I(120), cb1, (void *)&vt_obj1);
                palSetPad(IOPORT4, 2);
                //printf("LavagemMotor1-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                palClearPad(IOPORT4, 2);
                //printf("LavagemMotor1-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--LavagemMotor1-TOGGLE; ");
        	    S1311_Motor1_S1312_Motor2_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1312_Motor2(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj1, TIME_MS2I(120), cb1, (void *)&vt_obj1);
                palSetPad(IOPORT4, 3);
                //printf("LavagemMotor2-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                palClearPad(IOPORT4, 3);
                //printf("LavagemMotor2-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	    //printf("D--LavagemMotor2-TOGGLE; ");
        	    S1312_Motor2_S1311_Motor1_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S132_AguaSaida(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                //printf("LavagemSaidaAgua-ENTRY; ");
                palSetPad(IOPORT2, 4);
                return EVENT_HANDLED;
        case EXIT_EVENT:
                //printf("LavagemSaidaAgua-EXIT; ");
                palClearPad(IOPORT2, 4);
                return EVENT_HANDLED;
        case EVENT_E:
        	    //printf("E--LavagemSaidaAgua-TanqueBaixo; ");
        	    S132_AguaSaida_S14_Enxague_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S14_Enxague(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
               palSetPad(IOPORT3, 3);
               // //printf("Enxague-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               // //printf("Enxague-EXIT; ");
                palClearPad(IOPORT3, 3);
                return EVENT_HANDLED;
        case INIT_EVENT:
               // //printf("Enxague-INIT; ");
                S14_Enxague_init_tran();
                return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S141_AguaEntra(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
               palSetPad(IOPORT2, 2);
               // //printf("EnxagueEntradaAgua-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               palClearPad(IOPORT2, 2);
               // //printf("EnxagueEntradaAgua-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_B:
        	  //  //printf("B--EnxagueEntradaAgua-TanqueAlto; ");
        	    S141_AguaEntra_S142_Motor_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S142_Motor(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj, TIME_S2I(5), cb, (void *)&vt_obj);
                ////printf("EnxagueMotor-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               // //printf("EnxagueMotor-EXIT; ");
                return EVENT_HANDLED;
        case INIT_EVENT:
                ////printf("EnxagueMotor-INIT; ");
                S142_Motor_init_tran();
                return EVENT_HANDLED;        
        case EVENT_C:
        	 //   //printf("C--EnxagueMotor-Timeout15s; ");
        	    S142_Motor_S143_AguaSaida_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1421_Motor1(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
               chVTSet(&vt_obj1, TIME_MS2I(120), cb1, (void *)&vt_obj1);
               palSetPad(IOPORT4, 2);
               // //printf("EnxagueMotor1-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               palClearPad(IOPORT4, 2);
               // //printf("EnxagueMotor1-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	  //  //printf("D--EnxagueMotor1-TOGGLE; ");
        	    S1421_Motor1_S1422_Motor2_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S1422_Motor2(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj1, TIME_MS2I(120), cb1, (void *)&vt_obj1);
                palSetPad(IOPORT4, 3);
                ////printf("EnxagueMotor2-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                palClearPad(IOPORT4, 3);
                ////printf("EnxagueMotor2-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_D:
        	  //  //printf("D--EnxagueMotor2-TOGGLE; ");
        	    S1422_Motor2_S1421_Motor1_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S143_AguaSaida(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                palSetPad(IOPORT2, 4);
                ////printf("EnxagueSaidaAgua-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
                palClearPad(IOPORT2, 4);
                ////printf("EnxagueSaidaAgua-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_E:
        	  //  //printf("E--EnxagueSaidaAgua-TanqueBaixo; ");
        	    S143_AguaSaida_S15_Centrifugacao_tran();
        	    return EVENT_HANDLED;
        }        

        return EVENT_NOT_HANDLED;
}

cb_status S15_Centrifugacao(event_t ev)
{
        switch(ev) {
        case ENTRY_EVENT:
                chVTSet(&vt_obj, TIME_S2I(5), cb, (void *)&vt_obj);
                palSetPad(IOPORT4, 2);
                palSetPad(IOPORT3, 4);
                ////printf("Centrifugacao-ENTRY; ");
                return EVENT_HANDLED;
        case EXIT_EVENT:
               palClearPad(IOPORT3, 4);
               palClearPad(IOPORT4, 2);
               // //printf("Centrifugacao-EXIT; ");
                return EVENT_HANDLED;
        case EVENT_C:
              //  //printf("C--Centrifugacao-Timeout20s; ");
                S15_Centrifugacao_S11_Espera_tran();
                return EVENT_HANDLED;
        }

        return EVENT_NOT_HANDLED;
}



thread_t *p_main_thread;


/*
static THD_WORKING_AREA(waThread1, 32);
static THD_FUNCTION(Thread1, arg) {

  (void)arg;
  chRegSetThreadName("Blinker");
  while (true) {
    palTogglePad(IOPORT2, PORTB_LED1);
   // chEvtSignal(p_main_thread, EVENT_MASK(0));
    chThdSleepMilliseconds(2500);
  }
}
*/

static THD_WORKING_AREA(waThread1, 32);     // Debounce, envia evento do botão
static THD_FUNCTION(Thread1, arg) {

  (void)arg;
  chRegSetThreadName("Thread1");
  
  int rc = 0;
  int i = 0;
  uint8_t j = 0;
  while(1)
  {
    if(palReadPad(IOPORT2, 1))
    {   
        if(i==0){rc=0;}

        j = 0;
        i++;
        if(i==7)
        {
           rc = 1;
        }
        if(i>14)
        {
           rc = 0;
        }
     
    } 
    else
    {
        i = 0;
        if(rc == 1)
        {
           j++;
           if(j==5)
           {
             rc =-1;
             palTogglePad(IOPORT2, PORTB_LED1);
             set_event(EVENT_A);
           }
        }
     }  
    chThdSleepMilliseconds(15);
  }
}

static THD_WORKING_AREA(waThread3, 32);     // Debounce, envia evento do botão
static THD_FUNCTION(Thread3, arg) {

  (void)arg;
  chRegSetThreadName("Thread3");
  
  int rc = 0;
  int i = 0;
  uint8_t j = 0;
  while(1)
  {
    if(palReadPad(IOPORT2, 3))
    {   
        if(i==0){rc=0;}

        j = 0;
        i++;
        if(i==7)
        {
           rc = 1;
        }
        if(i>14)
        {
           rc = 0;
        }
     
    } 
    else
    {
        i = 0;
        if(rc == 1)
        {
           j++;
           if(j==5)
           {
             rc =-1;
             set_event(EVENT_B);
           }
        }
     }  
    chThdSleepMilliseconds(15);
  }
}



static THD_WORKING_AREA(waThread4, 32);     // Debounce, envia evento do botão
static THD_FUNCTION(Thread4, arg) {

  (void)arg;
  chRegSetThreadName("Thread4");
  
  int rc = 0;
  int i = 0;
  uint8_t j = 0;
  while(1)
  {
    if(palReadPad(IOPORT4, 4))
    {   
        if(i==0){rc=0;}

        j = 0;
        i++;
        if(i==7)
        {
           rc = 1;
        }
        if(i>14)
        {
           rc = 0;
        }
     
    } 
    else
    {
        i = 0;
        if(rc == 1)
        {
           j++;
           if(j==5)
           {
             rc =-1;
             set_event(EVENT_E);
           }
        }
     }  
    chThdSleepMilliseconds(15);
  }
}

static THD_WORKING_AREA(waThread5, 32);     // Debounce, envia evento do botão
static THD_FUNCTION(Thread5, arg) {

  (void)arg;
  chRegSetThreadName("Thread5");
  
  int rc = 0;
  int i = 0;
  uint8_t j = 0;
  while(1)
  {
    if(palReadPad(IOPORT4, 5))
    {   
        if(i==0){rc=0;}

        j = 0;
        i++;
        if(i==7)
        {
           rc = 1;
        }
        if(i>14)
        {
           rc = 0;
        }
     
    } 
    else
    {
        i = 0;
        if(rc == 1)
        {
           j++;
           if(j==5)
           {
             rc =-1;
             set_event(EVENT_F);
           }
        }
     }  
    chThdSleepMilliseconds(15);
  }
}



static THD_WORKING_AREA(waThread2, 32);
static THD_FUNCTION(Thread2, arg) {

  (void)arg;
  chRegSetThreadName("Thread2");
  event_t ev;
       chnWrite(&SD1, (const uint8_t *)"Hello !\r\nWorld", 14);


        while (1) {

                ev = wait_for_events();
                if (ev == EMPTY_EVENT)
                        break;
              //  printf("\n");
                dispatch_event(ev);
              //  chMtxLock(&mtx);
              //  chEvtSignalI(p_main_thread, 1);
              //  chMtxUnlock(&mtx);

        }
}

volatile uint8_t flag;


/*
 * Application entry point.
 */

int main(void) {

  halInit();
  chSysInit();

  p_main_thread = chThdGetSelfX();
  /*
   * Activates the serial driver 1 using the driver default configuration.
   */
  sdStart(&SD1, NULL);
  palSetPadMode(IOPORT2, 0, PAL_MODE_OUTPUT_PUSHPULL);  // Led, funcionando
  palSetPadMode(IOPORT2, 1, PAL_MODE_INPUT);            // Botão iniciar
  palSetPadMode(IOPORT2, 2, PAL_MODE_OUTPUT_PUSHPULL);  // Led, entrada água
  palSetPadMode(IOPORT2, 3, PAL_MODE_INPUT);            //Botão tanque cheio 
  palSetPadMode(IOPORT2, 4, PAL_MODE_OUTPUT_PUSHPULL);  //Led, saída água (vermelho)
  palSetPadMode(IOPORT4, 4, PAL_MODE_INPUT);            //Botão tanque vazio
  
  palSetPadMode(IOPORT3, 1, PAL_MODE_OUTPUT_PUSHPULL);  //led, molho
  palSetPadMode(IOPORT3, 2, PAL_MODE_OUTPUT_PUSHPULL);  //led, lavagem
  palSetPadMode(IOPORT3, 3, PAL_MODE_OUTPUT_PUSHPULL);  //led, enxague
  palSetPadMode(IOPORT3, 4, PAL_MODE_OUTPUT_PUSHPULL);  //led, centrifugacao
  
  palSetPadMode(IOPORT4, 2, PAL_MODE_OUTPUT_PUSHPULL); //led, motor 1
  palSetPadMode(IOPORT4, 3, PAL_MODE_OUTPUT_PUSHPULL); //led, motor2
  
  palSetPadMode(IOPORT4, 5, PAL_MODE_INPUT); //botão, fechado
  
 
  palClearPad(IOPORT2, 2);
    palClearPad(IOPORT2, 4);
  palClearPad(IOPORT3, 1);
  palClearPad(IOPORT3, 2);
  palClearPad(IOPORT3, 3);
  palClearPad(IOPORT3, 4);
  palClearPad(IOPORT4, 2);
  palClearPad(IOPORT4, 3);
  
  chVTObjectInit(&vt_obj);
    chVTObjectInit(&vt_obj1);

  //chVTSetI(&vt_obj, TIME_MS2I(100), cb, (void *)&vt_obj);


  init_machine(init_cb);

  
  
   chnWrite(&SD1, (const uint8_t *)"Hello !\r\nWorld", 14);

  chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO, Thread1, NULL);  // debounce, iniciar
  chThdCreateStatic(waThread2, sizeof(waThread2), NORMALPRIO, Thread2, NULL);
  chThdCreateStatic(waThread3, sizeof(waThread3), NORMALPRIO, Thread3, NULL);  // debounce, entrada água
  chThdCreateStatic(waThread4, sizeof(waThread4), NORMALPRIO, Thread4, NULL);  // debounce, saída água
  chThdCreateStatic(waThread5, sizeof(waThread5), NORMALPRIO, Thread5, NULL);  // debounce fechado
  
  uint8_t X;
  
  while(TRUE) {
     // palTogglePad(IOPORT2, PORTB_LED1);
     // palTogglePad(IOPORT2, 0);
     // X = palReadPad(IOPORT4, 4);
     // chprintf((BaseSequentialStream *)&SD1, "%d \n", X);
       //chEvtWaitOne (EVENT_MASK(0));

      flag =0;
  /*    for(int i=0; i<DEPTH; i++)
          ch//printf((BaseSequentialStream *)&SD1, "%d %d %d\n", buffer[i*NBR_CHANNELS], buffer[i*NBR_CHANNELS + 1], buffer[i*NBR_CHANNELS + 2]);*/
      chThdSleepMilliseconds(500);
  }
}
