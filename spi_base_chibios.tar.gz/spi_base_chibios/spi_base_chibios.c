
#include "ch.h"
#include "hal.h"


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "sm_base.h"


eventos g_input = EV_INVALID;

#define LED_PAD PORTB_LED1
#define LED_PORT IOPORT2

uint8_t g_buffer[1];                                          

 semaphore_t g_sem;

const char MQ_NAME_UP[] = "/rocket_down_mq2";
const char MQ_NAME_DOWN[] = "/rocket_up_mq2";

static const SPIConfig spiCfg = {
  NULL,                         /* SPI callback.                  */
  IOPORT2,                      /* SPI chip select port.          */
  SPI1_SS,                            /* SPI chip select pad.           */
  SPI_CR_DORD_MSB_FIRST     |   /* SPI Data order.                */
  SPI_CR_CPOL_CPHA_MODE(0)  |   /* SPI clock polarity and phase.  */
  SPI_CR_SCK_FOSC_128,          /* SPI clock.                     */
  SPI_SR_SCK_FOSC_2,             /* SPI double speed bit.          */
  SPI_ROLE_MASTER
};


static THD_WORKING_AREA(waThread1, 32);
static THD_FUNCTION(Thread1, arg) {

  (void)arg;
  chRegSetThreadName("Thread1");
 
        while (1) {     
                                                                     
           sdRead(&SD1, g_buffer, 1);
           if(g_buffer[0] == 'S') {
          //  printf("Receiving an ACK\n"); 
                 g_input = EV_SOT;
                 chSemSignal(&g_sem);     

        } else if(g_buffer[0] == 'E') {
          //  printf("Receiving an EOT\n");
            g_input = EV_EOT;
            chSemSignal(&g_sem);                                   

        } else {   chSemSignal(&g_sem);  }
         //   fprintf(stderr, "Unknown message received...\n");
            chThdSleepMilliseconds(2000);

        }
}


void send_ack()
{
    const char ack[] = "ACK";
    sdWrite(&SD1, (const uint8_t*) ack, strlen(ack));
    spiSelect(&SPID1);
    spiSend(&SPID1, strlen(ack), (const uint8_t*) ack);
    spiUnselect(&SPID1);
 
}

void send_eot()
{
    const char eot[] = "EOT";
    sdWrite(&SD1, (const uint8_t*) eot, strlen(eot));
    spiSelect(&SPID1);
     spiSend(&SPID1, strlen(eot), (const uint8_t*) eot);
    spiUnselect(&SPID1);
  
}

/*void timer_cb(union sigval value)
{
}*/

void setup_timers()
{
   
}


/*void mq_cb(union sigval value)
{
}*/


void setup_msgqueue()
{
    
  
}

void setup_all()
{
    setup_msgqueue();
    setup_timers();
}

void stop_timers()
{
}

void stop_msgqueue()
{
   
}

void stop_all()
{
    stop_msgqueue();
    stop_timers();
}

void start_timer_session()
{
}

// inicio codigo novo
void init_sm()
{
  //  printf (" 'esperando por SOT' \n ");
    g_state = ST_WAIT_SOT;
}

void tout_sessao()
{
  //  printf (" 'estouro no tempo de sessão' \n");
}

void unexpected_sot() {
}

/*void cancela_timer(timer_t timer)                
{
   
}*/

int rnd;
int processa_sot()
{
   // cancela_timer(g_timer1);

    send_ack();
}

void processa_dados()
{
  //  printf(" 'continua a receber dados' \n");
}
void processa_send_data_base_begin() 
{
  //  printf(" ' dados recebidos, transicao para o enviar dados ' \n");
    /* Mandando um EOT por enquanto só para testar o foguete */
    const char msg[] = "EOT";
    sdWrite(&SD1, (const uint8_t*) msg, strlen(msg));
    spiSelect(&SPID1);
    spiSend(&SPID1, strlen(msg), (const uint8_t*) msg);
    spiUnselect(&SPID1);
}

void processa_send_data_base()
{
   // printf(" 'continua a enviar dados da base' \n");
}
void processa_send_data()
{
  //  printf(" 'continua a enviar dados da base' \n");
    const char msg[] = "DATA";
    sdWrite(&SD1, (const uint8_t*) msg, strlen(msg));
    spiSelect(&SPID1);
    spiSend(&SPID1, strlen(msg), (const uint8_t*) msg);
    spiUnselect(&SPID1);
 
}
void processa_tout()
{
   // printf(" estouro no tempo, transicao para 'esperando dados' \n ");
}
void processa_eot_base()
{
  //  printf(" transicao para o estado 'esperando dados' \n");
}
// fim!!!!


/*
static THD_WORKING_AREA(waThread2, 32);
static THD_FUNCTION(Thread2, arg) {

  (void)arg;
  chRegSetThreadName("Thread2");
 
        while (1) {

           // palTogglePad(IOPORT2, 0);
            g_input = EV_SOT;
            chSemSignal(&g_sem);
            chThdSleepMilliseconds(2000);
            
            g_input = EV_EOT;
            chSemSignal(&g_sem);
            chThdSleepMilliseconds(2000);
        }
}

*/


int main(void)
{
    halInit();
    chSysInit();

    setup_all();

    chSemObjectInit(&g_sem, 0);
   
    sdStart(&SD1, NULL);
    spiStart(&SPID1, &spiCfg);
    palSetPadMode(IOPORT2, 0, PAL_MODE_OUTPUT_PUSHPULL);
    palSetPadMode(IOPORT2, SPI1_SS, PAL_MODE_OUTPUT_PUSHPULL);      //2
    palSetPadMode(IOPORT2, SPI1_MOSI, PAL_MODE_OUTPUT_PUSHPULL);    //3
    palSetPadMode(IOPORT2, SPI1_MISO, PAL_MODE_INPUT);              //4
    palSetPadMode(IOPORT2, SPI1_SCK, PAL_MODE_OUTPUT_PUSHPULL);     //5
    
    palClearPad(IOPORT2, 0);
    

    chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO, Thread1, NULL);
    init_sm();

    //chThdCreateStatic(waThread2, sizeof(waThread2), NORMALPRIO, Thread2, NULL);      //thread criada para enviar eventos e testar serial

    while (1) {
                 
        chSemWait(&g_sem);
      //  palTogglePad(LED_PORT, LED_PAD); 
        palTogglePad(IOPORT2, 0);                             
        processa_evento(g_input);
        g_input = EV_INVALID;

    }

    stop_all();
    spiStop(&SPID1);
    return 0;
}


